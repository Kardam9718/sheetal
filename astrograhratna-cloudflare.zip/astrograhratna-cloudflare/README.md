# Astrograhratna — Cloudflare Pages build

Static, crawlable multi-page site preserving the original visual language and Google Form lead workflow.

## Deploy
1. Create a Cloudflare Pages project.
2. Choose **Direct Upload** and upload the contents of this folder, or connect a Git repository.
3. Build command: leave blank. Output directory: `/` (repository root).
4. Add custom domain `astrograhratna.in`; keep the included `www` redirect.
5. After DNS is active, submit `https://astrograhratna.in/sitemap.xml` in Google Search Console.

## Before production
- Replace any stock or third-party images with owned product photography.
- Confirm every certification statement against the exact product report.
- Replace/expand policy text with business-approved terms.
- Test Google Form field IDs after any Google Form edit.
- Verify phone number and add a business email/address.
